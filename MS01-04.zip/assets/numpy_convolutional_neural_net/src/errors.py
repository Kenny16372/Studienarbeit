class InvalidPaddingModeError(Exception):
    pass
